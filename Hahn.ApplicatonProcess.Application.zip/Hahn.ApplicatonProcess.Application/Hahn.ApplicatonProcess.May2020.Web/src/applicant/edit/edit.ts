import { inject, autoinject } from "aurelia-framework";
import {
  ValidationControllerFactory,
  ValidationRules,
} from "aurelia-validation";
import { BootstrapFormRenderer } from "../../bootstrap-form-renderer";
import { HttpClient, json } from "aurelia-fetch-client";
import { Router } from "aurelia-router";
import { DialogService } from "aurelia-dialog";

let httpClient = new HttpClient();

@inject(ValidationControllerFactory, HttpClient, Router, DialogService) //, DialogService
export class EditApplicant {
  //static inject = [DialogService];

  controller = null;
  router: Router;

  applicant = new Applicant();

  url = "";

  rules;
  httpClient = new HttpClient();

  countries;

  i18n;
  dialogService: DialogService;
  constructor(
    controllerFactory,
    router: Router,
    dialogService: DialogService,
    i18n
  ) {
    this.controller = controllerFactory.createForCurrentScope();
    this.controller.addRenderer(new BootstrapFormRenderer());

    // this.applicant = new Applicant();
    // this.controller.addObject(this.applicant);

    // this.router = router;
    this.dialogService = dialogService;
    this.populateCountries();
  }

  activate(params, router: Router) {
    this.getData(params.id);
    // console.log("router");
    // console.log(router);
    // this.router = router;
    // this.applicant = new Applicant();
    // //this.controller.addObject(this);
    this.router = router;
    // this.populateCountries();

    this.controller.addObject(this.applicant);
  }

  getData(id) {
    this.url = "api/Applicant/" + id;
    httpClient
      .fetch(this.url)
      .then((response) => response.json())
      .then((data) => {
        this.applicant = data;
        console.log(this.applicant);
      });
  }

  populateCountries() {
    httpClient
      .fetch("https://restcountries.eu/rest/v2/")
      .then((result) => result.json())
      .then((data) => {
        this.countries = Object(data);
      });
  }

  updateApplicant(applicant: Applicant, id: number) {
    this.url = "api/Applicant/" + id;

    applicant.Age = Number(applicant.Age);

    httpClient
      .fetch(this.url, {
        method: "put",
        body: json(applicant),
        headers: { "Content-type": "application/json; charset=UTF-8" },
      })
      .then((response) => response.json())
      .then((data) => {})
      .catch((error) => {
        console.log("error");
        console.log(error);
      });
  }

  addApplicant(applicant: Applicant) {
    this.url = "api/Applicant/";

    this.applicant = applicant;

    console.log(this.applicant);

    console.log(this.controller);
    console.log(this.controller.errors);
    this.controller.validate();

    // Converting Age string to integer
    // applicant.Age = parseInt(applicant.Age);

    httpClient
      .fetch(this.url, {
        method: "post",
        body: json(applicant),
        headers: { "Content-type": "application/json; charset=UTF-8" },
      })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.status === 400) {
        } else {
          this.router.navigateToRoute("success");
        }
      })
      .catch((error) => {
        console.log("error");
        console.log(error);
      });
  }
}

export class Applicant {
  ID: string;
  Name: string;
  FamilyName: string;
  Address: string;
  EmailAddress: string;
  Country: string;
  Age: number;
  hired: boolean;
}

//Validation Rules for the fields
ValidationRules
  //Name
  .ensure((a: Applicant) => a.Name)
  .minLength(5)
  .maxLength(250)
  .required()
  //Family Name
  .ensure((a) => a.FamilyName)
  .minLength(5)
  .maxLength(250)
  .required()
  //Address
  .ensure((a) => a.Address)
  .minLength(10)
  .maxLength(500)
  .required()
  //Email Address
  .ensure((a) => a.EmailAddress)
  .email()
  .required()
  //Age
  .ensure((a) => a.Age)
  .between(20, 60)
  .required()
  .on(Applicant);
