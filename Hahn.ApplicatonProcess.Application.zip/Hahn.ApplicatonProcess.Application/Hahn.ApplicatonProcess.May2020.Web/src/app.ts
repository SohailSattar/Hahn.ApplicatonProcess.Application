import { PLATFORM } from "aurelia-pal";
import { Router, RouterConfiguration } from "aurelia-router";

export class App {
  public router: Router;

  public configureRouter(config: RouterConfiguration, router: Router) {
    config.title = "Hahn Software Development";
    config.map([
      {
        route: ["", "home"],
        name: "home",
        moduleId: PLATFORM.moduleName("./home"),
        nav: true,
        title: "Home",
      },
      {
        route: "applicant",
        name: "applicant",
        settings: { icon: "th-list" },
        moduleId: PLATFORM.moduleName("./applicant/applicant"),
        nav: false,
        title: "Applicant",
      },
      {
        route: "edit",
        name: "edit",
        settings: { icon: "th-list" },
        moduleId: PLATFORM.moduleName("./applicant/edit/edit"),
        nav: false,
        title: "Applicant - Edit",
      },
      {
        route: "success",
        name: "success",
        settings: { icon: "th-list" },
        moduleId: PLATFORM.moduleName("./applicant/success/success"),
        nav: false,
        title: "Success",
      },
    ]);

    this.router = router;
  }
}
