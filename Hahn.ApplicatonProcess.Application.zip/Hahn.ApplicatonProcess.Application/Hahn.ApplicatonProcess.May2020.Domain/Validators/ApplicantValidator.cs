﻿using Hahn.ApplicatonProcess.May2020.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;

namespace Hahn.ApplicatonProcess.May2020.Domain.Validators
{
    public class ApplicantValidator : AbstractValidator<Applicant>
    {
        //Maximum and Minimum values.
        //NOTE: MinLength should never be greater than Max Length
        //First and Family Name Min and Max length values
        private const int NameMinLength = 5;
        private const int NameMaxLength = 50;

        //Address Min and Max length values
        private const int AddressMinLength = 10;
        private const int AddressMaxLength = 250;

        //Age Min and Max length values
        private const int AgeMinLength = 20;
        private const int AgeMaxLength = 60;


        public ApplicantValidator()
        {
            RuleFor(x => x.Name).NotNull().WithMessage("Name field shouldn't be empty").Length(NameMinLength, NameMaxLength).WithMessage("Name should be atleast 5 or more characters long");
            RuleFor(x => x.FamilyName).NotNull().WithMessage("Family Name field shouldn't be empty").Length(NameMinLength, NameMaxLength).WithMessage("Family Name should be atleast 5 or more characters long");
            RuleFor(x => x.Address).NotNull().WithMessage("Address is required").Length(AddressMinLength, AddressMaxLength).WithMessage("Family Name should be atleast 10 or more characters long"); ;
            RuleFor(x => x.CountryOfOrigin).Length(10, 250);
            RuleFor(x => x.EmailAddress).EmailAddress();
            RuleFor(x => x.Age).InclusiveBetween(AgeMinLength, AgeMaxLength);

            //If not provided, Hired default's value will be False anyways, so below validation will always work.
            RuleFor(x => x.Hired).NotNull();
        }
    }
}
