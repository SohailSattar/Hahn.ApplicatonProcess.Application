﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.May2020.Domain
{
    //BONUS
    //This class contain Machine Learning logic which shall predict the average salaries based on the applicant's experience.
    class MachineLearning
    {
    }
}
