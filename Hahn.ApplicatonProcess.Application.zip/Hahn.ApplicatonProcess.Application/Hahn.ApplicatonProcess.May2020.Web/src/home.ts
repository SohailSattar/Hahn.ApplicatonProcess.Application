// import {computedFrom} from 'aurelia-framework';

// export class Welcome {
//   public heading: string = 'Welcome to the Aurelia Navigation App!';
//   public firstName: string = 'John';
//   public lastName: string = 'Doe';
//   private previousValue: string = this.fullName;

//   // Getters can't be directly observed, so they must be dirty checked.
//   // However, if you tell Aurelia the dependencies, it no longer needs to dirty check the property.
//   @computedFrom('firstName', 'lastName')
//   get fullName(): string {
//     return `${this.firstName} ${this.lastName}`;
//   }

//   public submit() {
//     this.previousValue = this.fullName;
//     alert(`Welcome, ${this.fullName}!`);
//   }

//   public canDeactivate(): boolean | undefined {
//     if (this.fullName !== this.previousValue) {
//       return confirm('Are you sure you want to leave?');
//     }
//   }
// }

// export class UpperValueConverter {
//   public toView(value: string): string {
//     return value && value.toUpperCase();
//   }
// }

import { HttpClient } from "aurelia-fetch-client";
import { inject } from "aurelia-framework";
import { Router } from "aurelia-router";
let httpClient = new HttpClient();
import { I18N } from "aurelia-i18n";

@inject(HttpClient, Router, I18N)
export class Home {
  //static inject = [I18N];
  public applicants: Applicant[];
  url = "";
  i18n: I18N;
  router: Router;
  constructor(http: HttpClient, router: Router, i18n) {
    this.getAllApplicants();

    this.router = router;

    this.i18n = i18n;

    console.log(this.i18n);
    this.i18n.setLocale("de-DE").then((e) => {
      // locale is loaded
      console.log("de-DE loaded");
      console.log(e);
    });

    console.log(this.i18n.getLocale());

    console.log("Here I am");

    console.log(this.i18n.tr("scores"));
  }

  getAllApplicants() {
    httpClient
      .fetch("api/Applicant/")
      .then((result) => result.json() as Promise<Applicant[]>)
      .then((data) => {
        this.applicants = data;
        console.log(data);
      });
    console.log("");
  }

  goToNewApplicant() {
    this.router.navigateToRoute("applicant");
  }

  edit(id) {
    this.router.navigateToRoute("edit", { id: id });
  }

  delete(id: number) {
    this.url = "api/Applicant/" + id;

    httpClient
      .fetch(this.url, {
        method: "delete",
      })
      .then((response) => response.json())
      .then((data) => {
        if (data) {
          this.getAllApplicants();
        }
      })
      .catch((error) => {
        console.log("error");
        console.log(error);
      });
  }
}

interface Applicant {
  ID: string;
  Name: string;
  FamilyName: string;
  address: string;
  emailAddress: string;
  Age: number;
  hired: boolean;
}
