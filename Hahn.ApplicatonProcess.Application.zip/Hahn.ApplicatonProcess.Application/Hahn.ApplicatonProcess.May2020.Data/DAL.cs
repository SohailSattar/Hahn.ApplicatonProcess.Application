﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore.InMemory;
using System.Runtime.CompilerServices;
using static Hahn.ApplicatonProcess.May2020.Data.DAL;
using System.Security.Cryptography.X509Certificates;

namespace Hahn.ApplicatonProcess.May2020.Data
{


    // This class is for read/write data i.e. Data Access Layer [DAL]
    public class DAL
    {
        //Database Models
        public interface IApplicant
        {
             int ID { get; set; }
            string Name { get; set; }
            string FamilyName { get; set; }
             string Address { get; set; }
             string CountryOfOrigin { get; set; }
             string EmailAddress { get; set; }
             int Age { get; set; }
             bool Hired { get; set; }
        }

        class Applicant : IApplicant
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public string FamilyName { get; set; }
            public string Address { get; set; }
            public string CountryOfOrigin { get; set; }
            public string EmailAddress { get; set; }
            public int Age { get; set; }
            public bool Hired { get; set; }


            public static List<Applicant> PopulateApplicants()
            {
                List<Applicant> applicants = new List<Applicant>();


                applicants.Add(new Applicant
                {
                    //ID = 1,
                    Name = "Alain",
                    FamilyName = "Bomerg",
                    Address = "123 Downtown, Dubai",
                    CountryOfOrigin = "United Arab Emirates",
                    EmailAddress = "alain.bomer@hotmail.com",
                    Age = 26,
                    Hired = true
                });

                applicants.Add(new Applicant {
                    Name = "Markus",
                    FamilyName = "Upston",
                    Address = "456, Berline",
                    CountryOfOrigin = "Germany",
                    EmailAddress = "mark.upston@gmmail.com",
                    Age = 40,
                    Hired = false
                });


                return applicants;
            }
        }

        private class MyContext : DbContext
        {
            public MyContext(DbContextOptions<MyContext> options)
            : base(options)
            {

            }
            public virtual DbSet<Applicant> Applicants { get; set; }

        }

        //protected internal virtual void OnConfiguring(Microsoft.EntityFrameworkCore.DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseInMemoryDatabase("");
        //}


        private static MyContext context;


        Array applicants;


        private Array GetAllApplicants()
        {
            var optionsBuilder = new DbContextOptionsBuilder<MyContext>();
            optionsBuilder.UseInMemoryDatabase("Hahn");
            optionsBuilder.EnableSensitiveDataLogging(false);

            //context = new MyContext(optionsBuilder.Options);

            if (context == null)
            {
                context = new MyContext(optionsBuilder.Options);

                foreach (Applicant applicant in Applicant.PopulateApplicants())
                {
                    context.Applicants.Add(applicant);
                }


                context.SaveChanges();


                return context.Applicants.ToArray();

            }
            applicants = context.Applicants.Local.ToArray();

            return applicants;
        }

        //TODO: Add code to fetch record
        public Array FetchApplicants()
        {
            applicants = GetAllApplicants();
            return applicants;
        }

        public object FetchApplicant(int id)
        {

            var categoryname = (context.Applicants
                       .Where(s => s.ID == id)
                       .FirstOrDefault<Applicant>());


            return categoryname;
        }

        public bool AddApplicant(IApplicant applicant)
        {
            Applicant newApplicant = new Applicant();
            //Setting the new ID to new applicant
            newApplicant.ID = context.Applicants.Local.Count + 1;
            newApplicant.Name = applicant.Name;
            newApplicant.FamilyName = applicant.FamilyName;
            newApplicant.Address = applicant.Address;
            newApplicant.EmailAddress = applicant.EmailAddress;
            newApplicant.CountryOfOrigin = applicant.CountryOfOrigin;
            newApplicant.Age = applicant.Age;
            newApplicant.Hired = applicant.Hired;

            try
            {
                //Setting the new ID to new applicant
                newApplicant.ID = context.Applicants.Local.Count + 1;
                newApplicant.Name = applicant.Name;
                newApplicant.FamilyName = applicant.FamilyName;
                newApplicant.Address = applicant.Address;
                newApplicant.EmailAddress = applicant.EmailAddress;
                newApplicant.CountryOfOrigin = applicant.CountryOfOrigin;
                newApplicant.Age = applicant.Age;
                newApplicant.Hired = applicant.Hired;
                context.Applicants.Add(newApplicant);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
            return true;
        }

        public bool UpdateApplicant(int ID, IApplicant applicant)
        {
            var result = context.Applicants.SingleOrDefault(a => a.ID == ID);
            if (result != null)
            {
                result.Name = applicant.Name;
                result.FamilyName = applicant.FamilyName;
                result.Address = applicant.Address;
                result.CountryOfOrigin = applicant.CountryOfOrigin;
                result.EmailAddress = applicant.EmailAddress;
                result.Age = applicant.Age;
                result.Hired = applicant.Hired;
                context.SaveChanges();

                return true;
            }
            return false;
        }

        public bool DeleteApplicant(int ID)
        {
            Applicant result = context.Applicants.SingleOrDefault(a => a.ID == ID);
            if (result != null)
            {
                context.Applicants.Remove(result);
                context.SaveChanges();

                return true;
            }
            return false;
        }
    }
}