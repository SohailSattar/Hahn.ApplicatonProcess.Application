﻿using System;
using System.Collections.Generic;
using Hahn.ApplicatonProcess.May2020.Data;
using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Newtonsoft.Json;

namespace Hahn.ApplicatonProcess.May2020.Domain
{
    public class BusinessLogic
    {
        #region EntityFramework

        // These methods are defined to handle EntityFramework operations.

        #region Retreive [GET]
        public string GetApplicantsEF()
        {
            DAL dal = new DAL();
            var obj = dal.FetchApplicants();
            string json = JsonConvert.SerializeObject(obj);
            return json;
        }

        public string GetApplicantsEF(int ID)
        {
            DAL dal = new DAL();

            var obj = dal.FetchApplicant(ID);


            string json = JsonConvert.SerializeObject(obj);

            return json;
        }

        #endregion

        #region Insert [POST]
        public bool AddApplicantEF(Applicant applicant)
        {
            DAL dal = new DAL();
            return dal.AddApplicant(applicant);
        }

        #endregion

        #region Update [PUT]

        public bool UpdateApplicantEF(int ID, Applicant applicant)
        {
            DAL dal = new DAL();
            return dal.UpdateApplicant(ID, applicant);
        }

        #endregion

        #region Delete [DELETE]
        public bool DeleteApplicantEF(int ID)
        {
            DAL dal = new DAL();
            return dal.DeleteApplicant(ID);
        }

        #endregion

        #endregion
    }
}
