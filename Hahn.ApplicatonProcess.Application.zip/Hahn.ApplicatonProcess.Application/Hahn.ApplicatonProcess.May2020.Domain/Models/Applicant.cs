﻿using FluentValidation;
using Hahn.ApplicatonProcess.May2020.Data;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using static Hahn.ApplicatonProcess.May2020.Data.DAL;

namespace Hahn.ApplicatonProcess.May2020.Domain.Models
{
    public class Applicant : IApplicant
    {
        /// <summary>
        /// Applicant's ID
        /// </summary>
        /// <example>1</example>
        public int ID { get; set; }

        /// <summary>
        /// Applicant's Name
        /// </summary>
        /// <example>Sohail</example>
        public string Name { get; set; }

        /// <summary>
        /// Applicant's Family name (Surname)
        /// </summary>
        /// <example>Rehmani</example>
        public string FamilyName { get; set; }


        /// <summary>
        /// Applicant's Family name (Surname)
        /// </summary>
        /// <example>Rehmani</example>
        public string Address { get; set; }
        public string CountryOfOrigin { get; set; }
        public string EmailAddress { get; set; }
        public int Age { get; set; }
        public bool Hired { get; set; }
    }

    public class ApplicantValidator : AbstractValidator<Applicant>
    {
        //Maximum and Minimum values.
        //NOTE: MinLength should never be greater than Max Length
        //First and Family Name Min and Max length values
        private const int NameMinLength = 5;
        private const int NameMaxLength = 50;

        //Address Min and Max length values
        private const int AddressMinLength = 10;
        private const int AddressMaxLength = 250;

        //Age Min and Max length values
        private const int AgeMinLength = 20;
        private const int AgeMaxLength = 60;


        public ApplicantValidator()
        {
            RuleFor(x => x.Name).NotNull().WithMessage("Name field shouldn't be empty").Length(NameMinLength, NameMaxLength).WithMessage("Name should be atleast 5 or more characters long");
            RuleFor(x => x.FamilyName).NotNull().WithMessage("Family Name field shouldn't be empty").Length(NameMinLength, NameMaxLength).WithMessage("Family Name should be atleast 5 or more characters long");
            RuleFor(x => x.Address).NotNull().WithMessage("Address is required").Length(AddressMinLength, AddressMaxLength).WithMessage("Address should be atleast 10 or more characters long");
            //RuleFor(x => x.CountryOfOrigin).Length(10, 250);
            RuleFor(x => x.EmailAddress).EmailAddress();
            RuleFor(x => x.Age).InclusiveBetween(AgeMinLength, AgeMaxLength);

            //If not provided, Hired default's value will be False anyways, so below validation will always work.
            RuleFor(x => x.Hired).NotNull();
        }
    }
}
