export class Success {}
