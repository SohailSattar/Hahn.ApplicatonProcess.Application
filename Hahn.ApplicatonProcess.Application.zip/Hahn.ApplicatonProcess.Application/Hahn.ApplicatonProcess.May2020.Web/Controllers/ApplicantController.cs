﻿using System.Collections.Generic;
using Hahn.ApplicatonProcess.May2020.Data;
using Hahn.ApplicatonProcess.May2020.Domain;
using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Microsoft.AspNetCore.Mvc;

namespace Hahn.ApplicatonProcess.May2020.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {
        // GET: api/<ApplicantController>
        [HttpGet]
        public string Get()
        {
            BusinessLogic bl = new BusinessLogic();
            string json = bl.GetApplicantsEF();

            return json;
        }

        // GET api/<ApplicantController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            BusinessLogic bl = new BusinessLogic();
            string json = bl.GetApplicantsEF(id);

            return json;
        }

        // POST api/<ApplicantController>
        [HttpPost]
        public bool Post([FromBody] Applicant applicant)
        {
            BusinessLogic bl = new BusinessLogic();
            return bl.AddApplicantEF(applicant);
        }

        // PUT api/<ApplicantController>/5
        [HttpPut("{id}")]
        public bool Put(int id, [FromBody] Applicant applicant)
        {
            BusinessLogic bl = new BusinessLogic();
            return bl.UpdateApplicantEF(id, applicant);
        }

        // DELETE api/<ApplicantController>/5
        [HttpDelete("{id}")]
        public bool Delete(int id)
        {
            BusinessLogic bl = new BusinessLogic();
            return bl.DeleteApplicantEF(id);
        }
    }
}
