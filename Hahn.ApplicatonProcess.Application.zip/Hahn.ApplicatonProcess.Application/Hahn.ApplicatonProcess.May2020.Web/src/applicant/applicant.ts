import { inject } from "aurelia-dependency-injection";
import {
  ValidationControllerFactory,
  ValidationRules,
} from "aurelia-validation";

import { BootstrapFormRenderer } from "../bootstrap-form-renderer";
import { HttpClient, json } from "aurelia-fetch-client";
import { Router } from "aurelia-router";

let httpClient = new HttpClient();

@inject(ValidationControllerFactory, HttpClient, Router) //, DialogService
export class NewApplicant {
  //static inject = [DialogService];

  controller = null;
  router: Router;

  applicant = new Applicant();

  url = "";

  rules;
  httpClient = new HttpClient();

  countries;

  i18n;
  constructor(controllerFactory, router: Router) {
    this.controller = controllerFactory.createForCurrentScope();
    this.controller.addRenderer(new BootstrapFormRenderer());

    this.applicant = new Applicant();
    this.controller.addObject(this.applicant);

    this.router = router;
    // this.dialogService = dialogService;
    this.populateCountries();
  }

  populateCountries() {
    //https://restcountries.eu/rest/v2/
    httpClient
      .fetch("https://restcountries.eu/rest/v2/")
      .then((result) => result.json())
      .then((data) => {
        this.countries = Object(data);
      });
  }

  addApplicant(applicant: Applicant) {
    this.url = "api/Applicant/";

    applicant.Age = Number(applicant.Age);
    console.log("json(applicant)");
    console.log(json(applicant));
    httpClient
      .fetch(this.url, {
        method: "post",
        body: json(applicant),
        headers: { "Content-type": "application/json; charset=UTF-8" },
      })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.status === 400) {
        } else {
          this.router.navigateToRoute("success");
        }
      })
      .catch((error) => {
        console.log("error");
        console.log(error);
      });
  }

  reset() {
    //  document.getElementById("myform").reset();
  }

  // openModal() {
  //   this.dialogService.open({});

  //   this.dialogService
  //     .open({
  //       viewModel: PopupDialog,
  //       model: "Are you sure?",
  //     })
  //     .then((response) => {
  //       console.log(response);

  //       if (!response.wasCancelled) {
  //         console.log("OK");
  //       } else {
  //         console.log("cancelled");
  //       }
  //       console.log("response.output");
  //     });

  //   //.reset();
  // }
}

//Regsitering reset button

export class Applicant {
  ID: string;
  Name: string;
  FamilyName: string;
  Address: string;
  EmailAddress: string;
  Country: string;
  Age: number;
  hired: boolean;
}

//Validation Rules for the fields
ValidationRules
  //Name
  .ensure((a: Applicant) => a.Name)
  .minLength(5)
  .maxLength(250)
  .required()
  //Family Name
  .ensure((a) => a.FamilyName)
  .minLength(5)
  .maxLength(250)
  .required()
  //Address
  .ensure((a) => a.Address)
  .minLength(10)
  .maxLength(500)
  .required()
  //Email Address
  .ensure((a) => a.EmailAddress)
  .email()
  .required()
  //Age
  .ensure((a) => a.Age)
  .between(20, 60)
  .required()
  .on(Applicant);
