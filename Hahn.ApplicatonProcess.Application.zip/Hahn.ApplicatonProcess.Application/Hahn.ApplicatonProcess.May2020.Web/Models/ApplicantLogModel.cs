﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.May2020.Web.Models
{
  public class ApplicantLogAModel
  {
  }

  public class AboutModel : PageModel
  {
    private readonly ILogger _logger;

    public AboutModel(ILogger<AboutModel> logger)
    {
      _logger = logger;
    }
    public string Message { get; set; }

    public void OnGet()
    {
      Message = $"About page visited at {DateTime.UtcNow.ToLongTimeString()}";
      _logger.LogInformation(Message);
    }
  }
}
